'use server';

import { type CoreUserMessage, generateText } from 'ai';
import { cookies } from 'next/headers';
import axios from 'axios';

import { customModel } from '@/lib/ai';
import {
  deleteMessagesByChatIdAfterTimestamp,
  getMessageById,
  updateChatVisiblityById,
} from '@/lib/db/queries';
import { VisibilityType } from '@/components/visibility-selector';

// GHL API Configuration
const GHL_BASE_URL = 'https://services.leadconnectorhq.com';
const GHL_API_KEY = process.env.PRIVATE_INTEGRATION_API_KEY;
const GHL_LOCATION_ID = process.env.GHL_LOCATION_ID;

// GHL API Integration Functions
async function fetchGHLData(endpoint: string, params = {}) {
  try {
    const response = await axios.get(`${GHL_BASE_URL}${endpoint}`, {
      headers: {
        Authorization: `Bearer ${GHL_API_KEY}`,
        'Content-Type': 'application/json',
      },
      params: {
        locationId: GHL_LOCATION_ID,
        ...params,
      },
    });
    return response.data;
  } catch (error) {
    console.error(`GHL API Error: ${error.message}`);
    throw new Error('Failed to fetch data from GHL');
  }
}

export async function getGHLContacts(limit = 5) {
  return await fetchGHLData('/contacts/', { limit });
}

export async function getGHLTasks(limit = 5) {
  return await fetchGHLData('/tasks/', { limit });
}

// Enhanced message generation with GHL context
export async function generateMessageWithGHLContext(message: string) {
  const [contacts, tasks] = await Promise.all([
    getGHLContacts(),
    getGHLTasks(),
  ]);

  const ghlContext = {
    recentContacts: contacts,
    recentTasks: tasks,
    message,
  };

  const { text } = await generateText({
    model: customModel('gpt-4'),
    system: `You are a GoHighLevel platform assistant. Use the provided GHL context to give relevant responses.`,
    prompt: JSON.stringify(ghlContext),
  });

  return text;
}

// Existing functions with GHL integration
export async function saveModelId(model: string) {
  const cookieStore = await cookies();
  cookieStore.set('model-id', model);
}

export async function generateTitleFromUserMessage({
  message,
}: {
  message: CoreUserMessage;
}) {
  const { text: title } = await generateText({
    model: customModel('gpt-4'),
    system: `
    - you will generate a short title based on the first message a user begins a conversation with
    - ensure it is not more than 80 characters long
    - the title should be a summary of the user's message
    - do not use quotes or colons`,
    prompt: JSON.stringify(message),
  });

  return title;
}

export async function deleteTrailingMessages({ id }: { id: string }) {
  const [message] = await getMessageById({ id });

  await deleteMessagesByChatIdAfterTimestamp({
    chatId: message.chatId,
    timestamp: message.createdAt,
  });
}

export async function updateChatVisibility({
  chatId,
  visibility,
}: {
  chatId: string;
  visibility: VisibilityType;
}) {
  await updateChatVisiblityById({ chatId, visibility });
}
