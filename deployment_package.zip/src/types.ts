
export interface GHLIntegrationConfig {
    apiKey: string;
    locationId: string;
    apiUrl: string;
}

export interface GHLResponse {
    success: boolean;
    data?: any;
    error?: string;
}

export interface WebhookPayload {
    event: string;
    data: any;
}
