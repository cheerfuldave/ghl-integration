'use client';

import { useEffect, useRef, useState } from 'react';

export function useGHLWebSocket() {
  const [data, setData] = useState(null);
  const ws = useRef(null);

  useEffect(() => {
    ws.current = new WebSocket(
      process.env.NODE_ENV === 'production'
        ? 'wss://' + window.location.host
        : 'ws://localhost:3000'
    );

    ws.current.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'GHL_UPDATE') {
          setData(message.data);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    };

    return () => {
      if (ws.current) {
        ws.current.close();
      }
    };
  }, []);

  return data;
}
