'use client';

import { useState } from 'react';
import { GHLIntegration } from './ghl-integration';

export function ChatWithGHL() {
  const [context, setContext] = useState({});
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const newMessage = { user: 'You', text: input };
    setMessages((prev) => [...prev, newMessage]);

    // Simulate AI response with GHL context
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input, context }),
    });

    const { reply } = await response.json();
    setMessages((prev) => [...prev, { user: 'AI', text: reply }]);
    setInput('');
  };

  return (
    <div className="chat-container">
      <GHLIntegration onContextUpdate={setContext} />

      <div className="messages">
        {messages.map((msg, index) => (
          <div key={index} className={`message ${msg.user === 'You' ? 'user' : 'ai'}`}>
            <strong>{msg.user}:</strong> {msg.text}
          </div>
        ))}
      </div>

      <div className="input-container">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
        />
        <button onClick={handleSendMessage}>Send</button>
      </div>
    </div>
  );
}
