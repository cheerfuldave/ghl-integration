import { describe, it, expect, jest } from '@jest/globals';
import { getGHLContacts, getGHLTasks, generateMessageWithGHLContext } from '@/app/(chat)/actions';

// Mock environment variables
process.env.PRIVATE_INTEGRATION_API_KEY = 'test-key';
process.env.GHL_LOCATION_ID = 'test-location';

// Mock axios
jest.mock('axios', () => ({
  get: jest.fn()
}));

describe('GHL Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should fetch contacts from GHL API', async () => {
    const mockContacts = [
      { id: 1, name: 'Test Contact' }
    ];

    axios.get.mockResolvedValueOnce({ data: mockContacts });

    const contacts = await getGHLContacts();
    expect(contacts).toEqual(mockContacts);
    expect(axios.get).toHaveBeenCalledWith(
      'https://services.leadconnectorhq.com/contacts/',
      expect.any(Object)
    );
  });

  it('should fetch tasks from GHL API', async () => {
    const mockTasks = [
      { id: 1, title: 'Test Task' }
    ];

    axios.get.mockResolvedValueOnce({ data: mockTasks });

    const tasks = await getGHLTasks();
    expect(tasks).toEqual(mockTasks);
    expect(axios.get).toHaveBeenCalledWith(
      'https://services.leadconnectorhq.com/tasks/',
      expect.any(Object)
    );
  });

  it('should generate message with GHL context', async () => {
    const mockContacts = [{ id: 1, name: 'Test Contact' }];
    const mockTasks = [{ id: 1, title: 'Test Task' }];
    const mockMessage = 'Test message';

    axios.get.mockResolvedValueOnce({ data: mockContacts });
    axios.get.mockResolvedValueOnce({ data: mockTasks });

    const response = await generateMessageWithGHLContext(mockMessage);
    expect(response).toBeTruthy();
    expect(axios.get).toHaveBeenCalledTimes(2);
  });

  it('should handle API errors gracefully', async () => {
    axios.get.mockRejectedValueOnce(new Error('API Error'));

    await expect(getGHLContacts()).rejects.toThrow('Failed to fetch data from GHL');
  });
});
